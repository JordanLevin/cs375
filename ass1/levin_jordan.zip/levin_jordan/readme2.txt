build program: make
run program:   ./program2 <filex> <filey> <output>

no fancy data structures
worst case time complexity is 2^n where every value is different because each function call makes 2 more.
no classes
