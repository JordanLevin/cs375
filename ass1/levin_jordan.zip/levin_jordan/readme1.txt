build program: make
run program:   ./program1 <filex> <filey> <output>

used a table for a bottom up dp solution
results in an m*n time where m is the length of file x and n is length of filey
no classes
