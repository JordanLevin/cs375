#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <ctime>

int helper(std::string x, std::string y, int xi, int yi);
int solve(std::string x, std::string y);

int main(int argc, char *argv[]){
    if(argc != 4){
        std::cout << "usage: ./ass1 <filex> <filey>\n";
        return -1;
    }
    std::string strx, stry;

    //setup io
    std::ifstream filex(argv[1]);
    std::ifstream filey(argv[2]);
    std::ofstream output(argv[3]);

    std::getline(filex, strx);
    std::getline(filey, stry);

    //time the function
    std::clock_t start;
    double duration;
    start = std::clock();

    int result = solve(strx, stry);
    
    duration = ( std::clock() - start  ) / (double) CLOCKS_PER_SEC;
    
    //output results
    output << result << '\n';
    output << duration << '\n';

    return 0;
}

//solve LCS with a recursive, assume neither string is empty and size <80
int solve(std::string x, std::string y){
    return helper(x, y, ((int)x.size())-1, ((int)y.size())-1);
}

//helper function which recursively calls itself decreasing the spot in the string each time
int helper(std::string x, std::string y, int xi, int yi){
    if(xi == -1 || yi == -1)
        return 0;
    if(x[xi] == y[yi])
        return helper(x, y, xi-1, yi-1) + 1;
    else
        return std::max(helper(x, y, xi, yi-1), helper(x, y, xi-1, yi));
}
