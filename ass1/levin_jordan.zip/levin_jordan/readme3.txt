build program: make
run program:   ./program3 <filex> <filey> <output>

uses a 2d vector for memoization.
ends up with an m*n time where m is the length of file x and n is length of filey
no classes
