#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <ctime>

std::vector<std::vector<int>> bottom_up(std::string x, std::string y);

int main(int argc, char *argv[]){
    if(argc != 4){
        std::cout << "usage: ./ass1 <filex> <filey>\n";
        return -1;
    }
    std::string strx, stry;

    //setup io
    std::ifstream filex(argv[1]);
    std::ifstream filey(argv[2]);
    std::ofstream output(argv[3]);

    std::getline(filex, strx);
    std::getline(filey, stry);

    //time the program
    std::clock_t start;
    double duration;
    start = std::clock();

    auto result = bottom_up(strx, stry);
    
    duration = ( std::clock() - start  ) / (double) CLOCKS_PER_SEC;

    int row = result.size()-1;
    int col = result[0].size()-1;
    
    if(row < 11 && col < 11){
        //output table
        for(const auto& row: result){
            for(const auto& val: row){
                output << val << " ";
            }
            output << '\n';
        }

        //determine lcs string
        std::string str;
        while(result[row][col] != 0){
            if(result[row][col] == result[row-1][col])
                row--;
            else if(result[row][col] == result[row][col-1])
                col--;
            else if(result[row][col] == result[row-1][col-1] + 1){
                str = stry[col-1] + str;
                row--;
                col--;
            }
        }
        //output string and time
        for(auto& c: str)
            output << c;
        output << '\n';
        output << duration << '\n';
    }
    else{
        output << result[row][col] << '\n';
        output << duration << '\n';
    }

    return 0;
}
    
//solve LCS with a bottom up dp solution, assume neither string is empty and size <80
std::vector<std::vector<int>> bottom_up(std::string strx, std::string stry){
    //create table
    std::vector<std::vector<int>> table(strx.size()+1);
    for(auto& row: table){
        row = std::vector<int>(stry.size()+1);
    }

    //initialize first row and col to 0
    for(size_t row = 0; row < table.size(); row++)
        table[row][0] = 0;
    for(size_t col = 0; col < table[0].size(); col++)
        table[0][col] = 0;

    
    //solve problem
    for(size_t row = 1; row < table.size(); row++){
        for(size_t col = 1; col < table[0].size(); col++){
            if(strx[row-1] == stry[col-1])
                table[row][col] = table[row-1][col-1] + 1;
            else
                table[row][col] = std::max(table[row-1][col], table[row][col-1]);
        }
    }
    return table;
}
